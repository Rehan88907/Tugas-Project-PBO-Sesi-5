/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.raihandaffaabdurrohmanproject;

/**
 *
 * @author JARKOM 13
 */
public class Main {
    public static void main(String[] args){
        Mobil mobil = new Mobil("Solih", "F4763SLH", 4);
        Motor motor = new Motor("Gilang", "F4667GLG", true);
        
        //Memanggil method tampilkanInfo
        System.out.println("Informasi Mobil:");
        mobil.tampilkanInfo();
        System.out.println("Informasi Motor:");
        motor.tampilkanInfo();
        
        //Memanggil method serviceKendaraan
        System.out.println("Melakukan servis tanpa parameter:");
        mobil.serviceKendaraan();
        motor.serviceKendaraan();
        
        System.out.println("Melakukan servis dengan parameter:");
        mobil.serviceKendaraan("Ganti Oli Mobil");
        motor.serviceKendaraan("Tune-Up Motor");
    }
}
