/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.raihandaffaabdurrohmanproject;

/**
 *
 * @author JARKOM 13
 */
public class RaihanDaffaAbdurrohmanproject {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
