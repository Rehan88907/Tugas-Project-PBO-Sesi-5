/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.raihandaffaabdurrohmanproject;

/**
 *
 * @author JARKOM 13
 */
public class Motor extends Kendaraan {
     boolean memilikiBox;
    
    //Constructor
    public Motor(String namaPemilik, String nomorPlat, boolean memilikiBox){
        super(namaPemilik, nomorPlat, "Motor");
        this.memilikiBox = memilikiBox;
    }
    
    //Override method tampilkanInfo
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        System.out.println("Memiliki Box " + (memilikiBox ? "Ya" : "Tidak"));
    }
}
