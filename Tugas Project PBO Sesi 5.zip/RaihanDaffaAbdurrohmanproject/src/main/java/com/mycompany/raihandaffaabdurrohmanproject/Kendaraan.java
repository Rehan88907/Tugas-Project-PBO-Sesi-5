/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.raihandaffaabdurrohmanproject;

/**
 *
 * @author JARKOM 13
 */
public class Kendaraan {
    String namaPemilik;
    String nomorPlat;
    String jenisKendaraan;
    
    //Constructor
    public Kendaraan(String namaPemilik, String nomorPlat, String jenisKendaraan){
        this.namaPemilik = namaPemilik;
        this.nomorPlat = nomorPlat;
        this.jenisKendaraan = jenisKendaraan;
        
    }
    
    public void tampilkanInfo(){
        System.out.println("Nama Pemiliki: " + namaPemilik);
        System.out.println("Nomor Plat: " + nomorPlat);
        System.out.println("Jenis Kendaraan: " + jenisKendaraan);
    }
    
    //Overloading method serviceKendaraan
    public void serviceKendaraan(){
        System.out.println("Servis Kendaraan sedang dilakukan.");
    }
    
    public void serviceKendaraan(String jenisService){
        System.out.println("Servis jenis " + jenisService + "Sedang dilakukan.");
    }
}
